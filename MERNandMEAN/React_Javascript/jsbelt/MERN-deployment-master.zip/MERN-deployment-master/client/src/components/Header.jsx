import React from "react"

const Header = props => {
    return(
        <div className="row" style={{marginTop: "20px", marginBottom: "20px"}}>
            <div className="col-12 text-center">
                <h1>Project Manager</h1>
            </div>
        </div>
    )
}

export default Header