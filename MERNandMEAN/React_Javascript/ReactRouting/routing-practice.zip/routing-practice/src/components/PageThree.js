import React from 'react';

const PageThree =(props)=>{
return(<div><p>The word is :{props.hello}</p></div>)
}

export default PageThree;