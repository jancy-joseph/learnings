import React from 'react';

const PageTwo =(props)=>{
    return(<div><p> The number is {props.id}</p></div>);
}
export default PageTwo;