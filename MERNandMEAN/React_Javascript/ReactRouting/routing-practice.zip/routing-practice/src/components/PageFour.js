import React from 'react';

const PageFour=(props)=>{
return( <div><p style={{color:props.blue,background:props.red}}>The word is :{props.hello}</p></div>)
}
export default PageFour;