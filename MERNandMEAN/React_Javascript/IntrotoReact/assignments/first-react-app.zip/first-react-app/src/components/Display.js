
import React, { Component } from 'react';

class Display extends Component{
    render() {
        return(
            <div>
                <h1>We are in the Component</h1>
                <h3>Things I need to do:</h3>
                <ul>
                    <li>Learn React</li>
                    <li>Climb Mt. Everest</li>
                    <li>Run a marathon</li>
                    <li> Test   </li>
                </ul>
            </div>
        );
    }
}

export default Display;