import React from 'react';

export default props => {
    return (
        <div>
            View One here
        </div>
    )
}