const mongoose = require('mongoose');
const Project = mongoose.model("Project");
//var ValidationError = mongoose.Error.ValidationError;



module.exports = {
    index: (req, res) => {
        Project.find()
            .then(allProjects => res.json({projects:allProjects}))
            //.catch(err => res.status(400).json(err))
            .catch(err => res.json({message: "Something went wrong", error: err}));

    },
    findById: (req, res) => {
        Project.findOne({_id: req.params.id})
            .then(project => res.json(project))
            .catch(err => res.status(400).json(err))
    },
    create: (req, res) => {
        const {name,dueDate,status} = req.body;
        Project.exists({name: req.body.name})
            .then(projectExists => {
                    if (projectExists) {
                        // Promise.reject() will activate the .catch() below.
                        return Promise.reject('Project with this name already exists');
                       //throw new Error('Pet with this name already exists');
                    }
                return Project.create(req.body);
            })
            .then(saveResult => res.json(saveResult))
            .catch(err => {
                console.log(err);
                if(typeof err ==="string"){
                    var newerror = {
                        "errors": {
                            "name": {
                                "properties": {
                                    "message": "Project with this name already exists",
                                    "type": "minlength",
                                    "minlength": 3,
                                    "path": "name",
                                    "value": "j"
                                },
                                "kind": "minlength",
                                "path": "name",
                                "value": "j"
                            }
                        },
                        "_message": "Project validation failed",
                        "message": "Project validation failed: name: Project with this name already exists"
                    }
                    res.status(400).json(newerror);
                }
                else{
                    res.status(400).json(err);
                }
                });
        // Project.create(req.body)
        //     .then(project => res.json(project))
        //     .catch(err => res.status(400).json(err))
    },
    delete: (req, res) => {
        Project.deleteOne({_id: req.params.id})
            .then(project => res.json(project))
            .catch(err => res.status(400).json(err))
    },
    edit: (req, res) => {
        console.log(req.params.id);
        console.log(req.body);
        Project.findOneAndUpdate({_id: req.params.id}, req.body, {new:true, runValidators:true, context:'query'})
        .then(project => {
                console.log(project);
                res.json(project);
            })
            .catch(err =>{
                console.log(err);
                res.status(400).json(err)
            })
    }
}