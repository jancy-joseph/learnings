import React, {useState} from 'react';
import axios from 'axios';

export default props => {
    const {project} = props;
    const today = useState(new Date().toISOString());
    
    const formatDate = (datetimeIsoString) => {
        let date = new Date(datetimeIsoString);
        let foramttedDate = date.getDate()+'/'+(date.getMonth()+1)+'/'+date.getFullYear();
        return foramttedDate;
    }
    const toggle = newStatus => {
        axios.put(`http://localhost:8002/api/project/${project._id}`, {"status": newStatus})
            .then(res => { console.log(res); })
            .catch(err => { console.log(err); })
    }

    const deleteProject = e => {
        axios.delete(`http://localhost:8002/api/project/${project._id}`)
            .then( res => {console.log(res)});
    }

    return (
        <div className="row m-2 p-3 border d-block">
            <div className="row-col">
                <h4>{project.name}</h4>
            </div>
            <div className="row-col">
                { today > project.dueDate ?
                    <span className="text-danger">Due date:&nbsp;{formatDate(project.dueDate)}</span>
                    :
                    <span className="text-success">Due date:&nbsp;{formatDate(project.dueDate)}</span>
                }
            </div>
            <div className="row-col">
                {project.status === "backlog" ?
                    <button className="btn-warning" onClick={(e)=> toggle("in_progress")}  >Start Project</button>
                    :
                    project.status === "in_progress" ?
                        <button className="btn-success" onClick={(e)=> toggle("completed")} >Move to Completed</button>
                        :
                        <button className="btn-danger" onClick={deleteProject} >Delete</button>
                }
            </div>
        </div>
    )
}