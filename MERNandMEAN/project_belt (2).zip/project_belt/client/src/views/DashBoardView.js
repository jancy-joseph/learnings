import React, { useEffect, useState } from 'react';
import {navigate} from '@reach/router';
import axios from 'axios';
import ProjectCard from '../components/ProjectCard';

export default props => {
    const [projects, setProjects] = useState([]);

    useEffect(()=> {
        axios.get('http://localhost:8002/api/projects')
            .then(response => { 
                console.log("Success");
                setProjects (
                    response.data.projects.sort((a,b) =>
                    (a.dueDate > b.dueDate )? 1: -1)
                ); 
            })
            .catch(err => console.log(err))
    },[projects]);

    return (
        <div className="container">
            <div className="row">
                <div className="col" style={{border: "2px solid black",backgroundColor:"blue"}}>
                    <h3>Backlog</h3>
                </div>
                <div className="col" style={{border: "2px solid black",backgroundColor:"yellow"}}> 
                    <h3>In Progress</h3>
                </div>
                <div className="col" style={{border: "2px solid black",backgroundColor:"green"}}>
                    <h3>Completed</h3>
                </div>
            </div>
            <div className="row overflow-auto" style={{height: '400px'}}>
                <div className="col" style={{border: "2px solid black"}}>
                    {
                    projects.filter((project => project.status === "backlog"))
                    .map((project, i) => 
                        <ProjectCard i={i} project={project}/>
                    )}
                </div>
                <div className="col" style={{border: "2px solid black"}}>
                    {projects.filter((project => project.status === "in_progress"))
                    .map((project, i) => 
                        <ProjectCard i={i} project={project}/>
                    )}
                </div>
                <div className="col" style={{border: "2px solid black"}}>
                    {projects.filter((project => project.status === "completed"))
                    .map((project, i) => 
                        <ProjectCard i={i} project={project}/>
                    )}
                </div>
            </div>
            <div className="row" style={{border: "2px solid black",height: '50px'}}>
                <div className="col pt-2">
                    <button onClick={(e)=>navigate("/new")}>Add New Project</button>
                </div>
            </div>
        </div>
    )
}