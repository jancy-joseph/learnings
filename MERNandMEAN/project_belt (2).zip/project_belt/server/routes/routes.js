const projects = require('../controllers/projects');

module.exports = (app) => {
    app.get('/api/projects', projects.index)
        .get('/api/project/:id', projects.findById)
        .post('/api/project/new', projects.create)
        .delete('/api/project/:id', projects.delete)
        .put('/api/project/:id', projects.edit);
}