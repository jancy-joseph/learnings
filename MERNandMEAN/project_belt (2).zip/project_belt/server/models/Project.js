const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Project name  is required"],
        minlength: [3, "Name must be at least 3 characters"]
    },
    dueDate: {
        type: Date,
        required: [true, "Due date is required"]
    },
    status: {
        type: String,
        default:"backlog"
    }

}, {timestamps: true});

mongoose.model("Project", ProjectSchema);