﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Name.Contains("Womens"));
            ViewBag.AllHockeyLeagues = context.Leagues.Where(l=>l.Sport.Contains("Hockey")).ToList();
            // var AllLeaguesFootBall = context.Leagues.Where(l=>l.Sport.Contains("Football")).ToList();
            // ViewBag.AllLeaguesExceptFootball = context.Leagues.Except(AllLeaguesFootBall);
            ViewBag.AllLeaguesExceptFootball = context.Leagues.Where(l=>l.Sport!="Football").ToList();
            ViewBag.AllConferenceLeagues = context.Leagues.Where(l=>l.Name.Contains("Conference")).ToList();
            ViewBag.AllAtlanticRegionLeagues = context.Leagues.Where(l=>l.Name.Contains("Atlantic")).ToList();
            ViewBag.AllDallasTeams = context.Teams.Where(t=>t.Location.Contains("Dallas")).ToList();
            ViewBag.AllRaptorsTeams = context.Teams.Where(t=>t.TeamName.Contains("Raptors")).ToList();
            ViewBag.AllCityTeams=context.Teams.Where(t=>t.Location.Contains("City")).ToList();
            ViewBag.AllTbeginingTeams = context.Teams.Where(t=>t.TeamName[0]=='T').ToList();
            ViewBag.AllOrderedTeamsByLocation = context.Teams.OrderBy(t=>t.Location);
            ViewBag.AllTeamsByTeamNamedescending = context.Teams.OrderByDescending(t=>t.TeamName);
            ViewBag.ALLCooperPlayers = context.Players.Where(p=>p.LastName.Contains("Cooper")).ToList();
            ViewBag.AllJoshuaPlayers = context.Players.Where(p=>p.FirstName.Contains("Joshua")).ToList();
            ViewBag.ALLNotJoshuaCooperPlayers = context.Players.Where(p=>p.LastName.Contains("Cooper") && p.FirstName!="Joshua").ToList();
            ViewBag.ALLAlexanaderOrWyattPlayers = context.Players.Where(p=>p.FirstName =="Alexander" || p.FirstName=="Wyatt").ToList();

            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}