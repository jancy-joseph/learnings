﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Name.Contains("Womens"));
            ViewBag.AllHockeyLeagues = context.Leagues.Where(l=>l.Sport.Contains("Hockey")).ToList();
            // var AllLeaguesFootBall = context.Leagues.Where(l=>l.Sport.Contains("Football")).ToList();
            // ViewBag.AllLeaguesExceptFootball = context.Leagues.Except(AllLeaguesFootBall);
            ViewBag.AllLeaguesExceptFootball = context.Leagues.Where(l=>l.Sport!="Football").ToList();
            ViewBag.AllConferenceLeagues = context.Leagues.Where(l=>l.Name.Contains("Conference")).ToList();
            ViewBag.AllAtlanticRegionLeagues = context.Leagues.Where(l=>l.Name.Contains("Atlantic")).ToList();
            ViewBag.AllDallasTeams = context.Teams.Where(t=>t.Location.Contains("Dallas")).ToList();
            ViewBag.AllRaptorsTeams = context.Teams.Where(t=>t.TeamName.Contains("Raptors")).ToList();
            ViewBag.AllCityTeams=context.Teams.Where(t=>t.Location.Contains("City")).ToList();
            ViewBag.AllTbeginingTeams = context.Teams.Where(t=>t.TeamName[0]=='T').ToList();
            ViewBag.AllOrderedTeamsByLocation = context.Teams.OrderBy(t=>t.Location);
            ViewBag.AllTeamsByTeamNamedescending = context.Teams.OrderByDescending(t=>t.TeamName);
            ViewBag.ALLCooperPlayers = context.Players.Where(p=>p.LastName.Contains("Cooper")).ToList();
            ViewBag.AllJoshuaPlayers = context.Players.Where(p=>p.FirstName.Contains("Joshua")).ToList();
            ViewBag.ALLNotJoshuaCooperPlayers = context.Players.Where(p=>p.LastName.Contains("Cooper") && p.FirstName!="Joshua").ToList();
            ViewBag.ALLAlexanaderOrWyattPlayers = context.Players.Where(p=>p.FirstName =="Alexander" || p.FirstName=="Wyatt").ToList();

            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            ViewBag.AtlanticSoccer = context.Teams
            .Include(t => t.CurrLeague)
            .Where(t => t.CurrLeague.Name == "Atlantic Soccer Conference");

            ViewBag.AllBostonPenguinsPlayers = context.Players
            .Include(t => t.CurrentTeam)
            .Where(t => t.CurrentTeam.TeamName == "Penguins"&& t.CurrentTeam.Location == "Boston");

            ViewBag.AllCollegeBAseballTeams= context.Teams
            .Include(t=>t.CurrLeague)
            .Where(t=>t.CurrLeague.Name=="International Collegiate Baseball Conference")
            .ToList();

            ViewBag.ACOAFootballTeams = context.Teams
            .Include(t=>t.CurrLeague)
            .Where(t=>t.CurrLeague.Name=="American Conference of Amateur Football")
            .ToList();

            ViewBag.AllFootballTeams = context.Teams
            .Include(t=>t.CurrLeague)
            .Where(t=>t.CurrLeague.Sport=="Football")
            .ToList();

            ViewBag.AllPlayerTeams = context.Teams
            .Include(t=>t.CurrentPlayers)
            .Where(t=>t.CurrentPlayers.FirstOrDefault(p=>p.FirstName=="Sophia")!= null)
            .ToList();

            ViewBag.FloresNotRaptor = context.Players
            .Include(p => p.CurrentTeam)
            .Where(p => p.CurrentTeam.TeamName != "Raptors" && p.LastName == "Flores");

            ViewBag.MTGC = context.Players
                    .Include(p => p.CurrentTeam)
                    .Where(p => p.CurrentTeam.TeamName == "Tiger-Cats" && p.CurrentTeam.Location == "Manitoba");

            ViewBag.all12CountTeams = context.Teams
            .Include(p=>p.AllPlayers)
            .Where(p=>p.AllPlayers.Count() >12).ToList();


// All teams in the American Conference of Amateur Football
ViewBag.ACAF = context.Teams
    .Include(t => t.CurrLeague)
    .Where(t => t.CurrLeague.Name == "American Conference of Amateur Football");

// All football teams
ViewBag.Football = context.Teams
    .Include(t => t.CurrLeague)
    .Where(t => t.CurrLeague.Sport == "Football");

// Teams with a current player named Sophia
ViewBag.WithSophia = context.Teams
    .Include(t => t.CurrentPlayers)
    .Where(t => t.CurrentPlayers.FirstOrDefault(p => p.FirstName == "Sophia") != null);

// Everyone with the last name "Flores" who DOESN'T currently play for the raptors
ViewBag.FloresNotRaptor = context.Players
    .Include(p => p.CurrentTeam)
    .Where(p => p.CurrentTeam.TeamName != "Raptors" && p.LastName == "Flores");

// All current players on the Manitoba Tiger-Cats
ViewBag.TigerCats = context.Players
    .Include(p => p.CurrentTeam)
    .Where(p => p.CurrentTeam.TeamName == "Tiger-Cats" && p.CurrentTeam.Location == "Manitoba");

// All teams that have had 12 or more players
ViewBag.TwelveOrMore = context.Teams
    .Include(t => t.AllPlayers)
    .Where(t => t.AllPlayers.Count >= 12);

            return View();

        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            // All teams past and present that Alexander Bailey has played with
ViewBag.BaileyTeams = context.Teams
    .Include(t => t.CurrentPlayers)
    .Include(t => t.AllPlayers)
    .ThenInclude(pt => pt.PlayerOnTeam)
    .Where(t => 
        t.AllPlayers.FirstOrDefault(p => p.PlayerOnTeam.FirstName == "Alexander" && p.PlayerOnTeam.LastName == "Bailey") != null 
        );  
        

// All players past and present with the Manitoba Tiger-Cats
Team tCats = context.Teams.FirstOrDefault(t => t.Location == "Manitoba" && t.TeamName == "Tiger-Cats");
ViewBag.TigerCats = context.Players
    .Include(p => p.CurrentTeam)
    .Include(p => p.AllTeams)
    .ThenInclude(at => at.TeamOfPlayer)
    .Where(p => 
        p.CurrentTeam == tCats ||
        p.AllTeams.FirstOrDefault(t => t.TeamOfPlayer.Location == "Manitoba" && t.TeamOfPlayer.TeamName == "Tiger-Cats") != null
        );

// All players formerly (and not currently) with the Wichita Vikings
Team vikings = context.Teams.FirstOrDefault(t => t.Location == "Wichita" && t.TeamName == "Vikings");
ViewBag.FormerVikings = context.Players
    .Include(p => p.CurrentTeam)
    .Include(p => p.AllTeams)
    .ThenInclude(at => at.TeamOfPlayer)
    .Where(p => 
        p.AllTeams.FirstOrDefault(at => at.TeamOfPlayer.TeamName == "Vikings" && at.TeamOfPlayer.Location == "Wichita") != null 
        &&
        p.CurrentTeam != vikings
        );

// Every team that Emily Sanchez played for before she joined the Indianapolis Athletics --> note the loop in cshtml
// loops through the ManyToMany entries rather than the Team entries

PlayerTeam EmilyRoyals = context.PlayerTeams
    .Include(pt => pt.TeamOfPlayer)
    .Include(pt => pt.PlayerOnTeam)
    .FirstOrDefault(pt => pt.PlayerOnTeam.FirstName == "Emily" && pt.PlayerOnTeam.LastName == "Sanchez" && pt.TeamOfPlayer.Location == "Indianapolis" && pt.TeamOfPlayer.TeamName == "Athletics");
    
ViewBag.PreRoyals = context.Players
    .Include(p => p.AllTeams)
    .ThenInclude(at => at.TeamOfPlayer)
    .FirstOrDefault(p => p.FirstName == "Emily" && p.LastName == "Sanchez")
    .AllTeams
    .Where(at => at.PlayerTeamId < EmilyRoyals.PlayerTeamId);

// everyone named Levi who has ever played in the Atlantic Federation of Amateur Baseball Players
ViewBag.AFABPPlayers = context.Players
    .Include(p => p.CurrentTeam)
    .ThenInclude(ct => ct.CurrLeague)
    .Include(p => p.AllTeams)
    .ThenInclude(at => at.TeamOfPlayer)
    .ThenInclude(tp => tp.CurrLeague)
    .Where(p => 
        p.FirstName == "Levi"
        &&
        (
            p.AllTeams
                .Where(at => at.TeamOfPlayer.CurrLeague.Name == "Atlantic Federation of Amateur Baseball Players")
                .Count() > 0
            ||
            p.CurrentTeam.CurrLeague.Name == "Atlantic Federation of Amateur Baseball Players"
        )
    );

// all players sorted by the number of teams they've played for
ViewBag.TNSort = context.Players
    .Include(p => p.CurrentTeam)
    .Include(p => p.AllTeams)
    .OrderByDescending(p => p.AllTeams.Count());

            return View();
        }

    }
}