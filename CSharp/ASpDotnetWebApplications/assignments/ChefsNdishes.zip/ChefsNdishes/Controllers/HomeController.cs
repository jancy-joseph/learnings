using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using ChefsNdishes.Models;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;

namespace ChefsNdishes.Controllers
{
   public class HomeController: Controller
    {
        private MyContext dbContext;

        public HomeController(MyContext context)
        {
            dbContext= context;
        }

        [HttpGet("")]
        public IActionResult HomePage()
        {
            ViewBag.AllChefsinDB = dbContext.Chefs
            .Include(x=>x.Dishes)
            .OrderByDescending(x=>x.Created_at)
            .ToList();
            return View();
        }

        [HttpGet("addNewChef")]
        public IActionResult addNewChef(Chef chef)
        {
            return View();
        }

        [HttpPost("createNewChef")]
        public IActionResult createNewChef(Chef submission)
        {
            if(ModelState.IsValid)
            {
                if(dbContext.Chefs.Any(x=>x.FirstName == submission.FirstName))
                {
                    ModelState.AddModelError("FirstName","Chef with that name already exists");
                    return RedirectToAction("addNewChef",submission);
                }
                dbContext.Chefs.Add(submission);
                dbContext.SaveChanges();
                return RedirectToAction("HomePage",submission);
            }
            else
            {
                return RedirectToAction("addNewChef",submission);
            }
        }
        [HttpGet("showAllDishes")]
        public IActionResult showAllDishes()
        {
            ViewBag.AllDishes = dbContext.Dishes
            .Include(x=>x.Chef)
            .OrderBy(x=>x.DishName)
            .ToList();
            return View();
        }
        
        [HttpGet("addNewDish")]
        public IActionResult addNewDish(Dish dsh)
        {
            ViewBag.AllChefsinDB = dbContext.Chefs
            .OrderByDescending(x=>x.Created_at)
            .ToList();
            return View();
        }

        [HttpPost("createNewDish")]
        public IActionResult createNewDish(Dish submission)
        {
            if(ModelState.IsValid)
            {
                 if(dbContext.Dishes.Any(x=>x.DishName == submission.DishName))
                {
                    ModelState.AddModelError("DishName","DishName with that name already exists");
                    return RedirectToAction("addNewChef",submission);
                }
                // Chef ToaddtoChef = dbContext.Chefs.FirstOrDefault(x=>x.ChefId == submission.ChefId);
                // ToaddtoChef.Dishes.Add(submission);
                dbContext.Dishes.Add(submission);
                dbContext.SaveChanges();
                return RedirectToAction("showAllDishes",submission);
           }
            else
            {
                return RedirectToAction("addNewDish",submission);
            }

        }

    
    }

}