using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace ChefsNdishes.Models
{
      public class FutureDateAttribute : ValidationAttribute
    {
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        // You first may want to unbox "value" here and cast to to a DateTime variable!
        if((DateTime)value > DateTime.Now){
            return new ValidationResult("No Future Dates are allowed!");
        }
        return ValidationResult.Success;

    }
    }

  public class ValidateAgeAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        // You first may want to unbox "value" here and cast to to a DateTime variable!
        DateTime givenage = (DateTime)value;
       
        if( (DateTime.Now.Year -givenage.Year) <18)
        {
            return new ValidationResult("We dont employ Minors.Every chef must be 18 years old at least");
        }
        return ValidationResult.Success;

    }
}

    public class Chef
    {
        [Key]
        public int ChefId { get; set; }
        [Required(ErrorMessage="FirstName is required")]
        public string FirstName { get; set; }
        [Required(ErrorMessage="LastName is required")]

        public string  LastName { get; set; } 
        [Required(ErrorMessage="DOB is required")]
        [FutureDate]
        [ValidateAge]
        public DateTime DOB{get;set;}


        [NotMapped]
        public int Age{
            get{
                return DateTime.Now.Year -DOB.Year;}
        }

        //12M
        public List<Dish> Dishes {get;set;}

        [NotMapped]
        public int TotalNoofDishes
        {
            get
            {
                int avg =0;
                if(Dishes==null) return avg;
                if(Dishes != null)
                {
                    avg = Dishes.Count;
                }
                return avg;

            }
        }

        public DateTime Created_at{get;set;} = DateTime.Now;
        public DateTime Updated_at{get;set;}= DateTime.Now;
        
        
    }
}