using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChefsNdishes.Models
{
    public class Dish
    {
        [Key]
        public int DsihId { get; set; }
        [Required(ErrorMessage="DishName is required")]

        public string DishName { get; set; }
        [Required(ErrorMessage="Calories is required")]

        [Range(1,Int32.MaxValue,ErrorMessage="Calories must be greater than 0")]
        public int Calories {get;set;}
        [Required(ErrorMessage="Description is required")]
        
        public string Description { get; set; } 
        [Required(ErrorMessage="Tastiness is required")]
        [Range(1,5,ErrorMessage="Calories must be between 1 to 5")]

        public int Tastiness { get; set; }
        
        
        [Required]

        //FKey to Chef
        public int ChefId { get; set; }
        //Nav to Chef
        public Chef Chef { get; set; }

        
        public DateTime Created_at{get;set;} = DateTime.Now;
        public DateTime Updated_at{get;set;}= DateTime.Now;
        

    }
}