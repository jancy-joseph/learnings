using System;
using System.Collections.Generic;

namespace newBelt.Models
{
    public class ShowActivityWrapper
    {
        public Activity newActivity{get;set;}
      //  public List<ActivityMember> AllMembers{get;set;}

        public User LoggedUser{get;set;}

//        public User ActivityCreator{get;set;}
        
    }
}