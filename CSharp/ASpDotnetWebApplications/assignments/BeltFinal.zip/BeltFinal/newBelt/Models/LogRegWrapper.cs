using System;

namespace newBelt.Models
{
    public class LogRegWrapper
    {
        public User RegUser { get; set; }
        public LoginUser LogUser { get; set; }
    }
}