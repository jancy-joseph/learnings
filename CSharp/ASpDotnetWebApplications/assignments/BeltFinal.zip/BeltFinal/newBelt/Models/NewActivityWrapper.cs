namespace newBelt.Models
{
    public class NewActivityWrapper
    {

        public Activity newActivity{get;set;}
        public User LoggedUser{get;set;}
        
    }
}