# Sweet Movie App
Example Movie Browser application using React/Redux built for [Medium article](https://medium.com/@levifuller/how-to-build-a-scalable-movie-browser-app-using-react-and-redux-in-visual-studio-code-dea8bfb3eabe)

![Movie Browser App](https://image.prntscr.com/image/BXSNDUqnT6aFwuOfQvNwQw.png)

Start the app with:

```
npm start
```

